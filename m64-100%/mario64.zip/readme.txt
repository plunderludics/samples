The SRAM filename must be the same as the game's 
Internal Name (check this with Project64's romlisting),
or it might now work.

Examples...
THE LEGEND OF ZELDA = This is Legend of Zelda: Ocarina of Time's Internal Name.
SUPER MARIO 64 = This is Super Mario 64's Internal Name.

Of course, you can change the SRAM filename to fit with other regional versions 
of the same game. It's just important to know the Internal Name of the game first 
before doing so.

This document is � DJSonic 2004